﻿"""Update inventory Delta table with sales deductions and log anomalies."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime
from pathlib import Path

from delta.tables import DeltaTable
from delta import configure_spark_with_delta_pip
from pyspark.sql import SparkSession, functions as F


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Apply sales deductions to local inventory Delta table.")
    parser.add_argument("--delta-dir", default=str(Path(__file__).resolve().parents[1] / "_delta"), help="Base directory containing inventory and sales Delta tables")
    parser.add_argument("--logs-dir", default=str(Path(__file__).resolve().parents[1] / "_logs"), help="Directory for generated log files")
    parser.add_argument("--shuffle-partitions", type=int, default=4, help="spark.sql.shuffle.partitions override")
    parser.add_argument("--days", type=int, default=7, help="Number of days of sales to apply (0 for all time)")
    return parser.parse_args(argv)


def build_spark(shuffle_partitions: int) -> SparkSession:
    builder = (
        SparkSession.builder.appName("GlobalElectronicsUpdateStocks")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.sql.shuffle.partitions", str(shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
    )
    spark = configure_spark_with_delta_pip(builder).getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    return spark


def ensure_dirs(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_invalid_sales(invalid_df, logs_dir: Path) -> int:
    invalid_rows = [row.asDict() for row in invalid_df.collect()]
    if not invalid_rows:
        return 0
    output_file = logs_dir / "invalid_sales.csv"
    with output_file.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=invalid_rows[0].keys())
        writer.writeheader()
        writer.writerows(invalid_rows)
    print(f"Logged {len(invalid_rows)} invalid sales rows to {output_file}")
    return len(invalid_rows)


def record_versions(
    logs_dir: Path,
    previous_version: int,
    current_version: int,
    days_applied: int,
    invalid_rows: int,
    valid_rows: int,
) -> None:
    metadata_file = logs_dir / "inventory_versions.json"
    payload = {
        "previous_version": previous_version,
        "current_version": current_version,
        "days_applied": days_applied,
        "invalid_rows": invalid_rows,
        "valid_rows": valid_rows,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    with metadata_file.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(f"Inventory versions recorded in {metadata_file}")


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    delta_dir = Path(args.delta_dir)
    logs_dir = Path(args.logs_dir)
    ensure_dirs(logs_dir)

    spark = build_spark(args.shuffle_partitions)

    inventory_path = str(delta_dir / "inventory")
    sales_path = str(delta_dir / "sales")

    if not Path(inventory_path).exists() or not Path(sales_path).exists():
        print("Inventory or sales Delta tables are missing. Run 1_local_ingest_delta.py first.")
        return 1

    inventory = DeltaTable.forPath(spark, inventory_path)
    sales_df = spark.read.format("delta").load(sales_path)

    if args.days > 0:
        cutoff = F.date_sub(F.current_date(), args.days)
        sales_df = sales_df.where(F.col("event_date") >= cutoff)
    else:
        cutoff = None

    existing_products = inventory.toDF().select("warehouse_code", "product_id").distinct()

    aggregated_sales = (
        sales_df.groupBy("warehouse_code", "product_id")
        .agg(
            F.sum("quantity").alias("quantity_sold"),
            F.sum("sale_amount_euro").alias("revenue_euro"),
            F.max("event_time").alias("last_sale_ts"),
        )
        .cache()
    )

    invalid_sales = aggregated_sales.join(existing_products, ["warehouse_code", "product_id"], "left_anti")
    invalid_rows = write_invalid_sales(invalid_sales, logs_dir)

    valid_sales = aggregated_sales.join(existing_products, ["warehouse_code", "product_id"], "inner")
    valid_rows = valid_sales.count()

    if valid_rows == 0:
        print("No valid sales to apply. Inventory not updated.")
        return 0

    history_before = inventory.history().select("version").orderBy("version", ascending=False).first()
    previous_version = history_before[0] if history_before else 0

    inventory.alias("target").merge(
        valid_sales.alias("source"),
        "target.warehouse_code = source.warehouse_code AND target.product_id = source.product_id",
    ).whenMatchedUpdate(
        set={
            "quantity_on_hand": F.greatest(F.col("target.quantity_on_hand") - F.col("source.quantity_sold"), F.lit(0)),
            "last_updated_ts": F.current_timestamp(),
            "last_sale_ts": F.col("source.last_sale_ts"),
            "lifetime_revenue_euro": (
                F.coalesce(F.col("target.lifetime_revenue_euro"), F.lit(0.0)) + F.col("source.revenue_euro")
            ).cast("double"),
        }
    ).execute()

    history_after = inventory.history().select("version").orderBy("version", ascending=False).first()
    current_version = history_after[0] if history_after else previous_version

    record_versions(logs_dir, previous_version, current_version, args.days, invalid_rows, valid_rows)

    negatives = inventory.toDF().where("quantity_on_hand < 0")
    if not negatives.rdd.isEmpty():
        count = negatives.count()
        print(f"Warning: {count} inventory rows have negative stock after merge.")
    else:
        print("Inventory merge successful with no negative stock.")

    if cutoff is not None:
        print(f"Sales applied from {args.days} trailing days (cutoff >= {cutoff}).")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
