﻿# Global Electronics Lakehouse (Databricks + Local)

![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white) ![PySpark](https://img.shields.io/badge/PySpark-3.5+-E25A1C?logo=apachespark&logoColor=white) ![Delta Live Tables](https://img.shields.io/badge/Delta%20Live%20Tables-Advanced-FFCF00) ![Docker](https://img.shields.io/badge/Docker-Compose-2496ED?logo=docker&logoColor=white)

Complete medallion lakehouse reference implementation for a multinational electronics retailer. The project ships with Databricks-ready Delta Live Tables pipelines, Databricks Asset Bundles, local PySpark notebooks, synthetic data, streaming emulation via Kafka, and analytics queries. Everything runs end-to-end in Databricks **and** entirely offline on a laptop.

---

## Repository Layout

```text
global_electronics_lakehouse/
├─ data/
│  ├─ inventory/YYYY-MM-DD/{FRA|BUC|MAD}_inventory.csv
│  ├─ sales_stream/sales_*.json
│  └─ suppliers/suppliers_master.jsonl
├─ resources/schemas/*.json
├─ src/dlt/electronics_dlt.{sql,py}
├─ src/streaming/
│  ├─ docker-compose.yaml
│  ├─ sales_producer.py
│  └─ README.md
├─ src/generate_synthetic_data.py
├─ notebooks_local/1..3_local_*.py
├─ queries/dashboard/*.sql
├─ bundle/databricks.yml
├─ README.md
├─ LICENSE
└─ .gitignore
```

---

## Quick Start — Databricks (Cloud)

1. **Provision catalog & volumes**
   - Create Unity Catalog catalog `main` (or reuse) and schema `electronics`.
   - Create Volumes under `main.electronics`:
     - `/Volumes/main/landing/electronics/inventory/`
     - `/Volumes/main/landing/electronics/sales_stream/`
     - `/Volumes/main/landing/electronics/suppliers/`
2. **Upload demo data**
   - Use Databricks File Browser, `dbutils.fs.cp`, or CLI to copy the `data/` folder contents into the corresponding volumes.
3. **Deploy DLT pipeline**
   - Option A: Import `src/dlt/electronics_dlt.sql` as a SQL pipeline in the UI.
   - Option B: Install Databricks CLI v0.205+, run `databricks bundle deploy --target dev` using `bundle/databricks.yml`.
4. **Configure pipeline settings**
   - Set `pipelines.electronics.source_inventory`, `source_sales`, `source_suppliers`, and `kafka_bootstrap` in the pipeline configuration (or via bundle `vars`).
   - Choose between the SQL pipeline or the PySpark alternative (`electronics_dlt.py`).
5. **Run pipeline**
   - Trigger a full refresh, then switch to continuous mode for streaming.
   - Monitor Expectations: `non_negative_inventory`, `quantity_positive`, `product_known`, etc. All must stay green.
6. **Analytics & dashboards**
   - Create a Lakehouse Dashboard or SQL queries using `queries/dashboard/*.sql` (use `gold` tables as sources).
   - Optional scheduled validation job ships in `bundle/databricks.yml` (`gold_quality_check`).
7. **Observability**
   - Monitor DLT event log, auto scaling, and pipeline metrics.
   - Add DLT alerts / data quality notifications as needed.

---

## Quick Start — Local Laptop

1. **Prerequisites**
   - CPU ≥ 8 cores, RAM ≥ 16 GB, SSD ≥ 30 GB free.
   - Python 3.10+, Java 11/17, Docker Desktop (WSL2 on Windows).
   - Install deps: `pip install pyspark delta-spark kafka-python`.
2. **Generate synthetic data (once)**
   ```bash
   python src/generate_synthetic_data.py --products 2500 --days 7
   ```
3. **Start Kafka stack**
   ```bash
   cd src/streaming
   docker compose up -d
   ```
4. **Replay streaming demo (optional)**
   ```bash
   python src/streaming/sales_producer.py --rate 25 --replay
   ```
5. **Ingest raw data into local Delta tables**
   ```bash
   spark-submit notebooks_local/1_local_ingest_delta.py
   ```
6. **Apply incremental sales to inventory (MERGE)**
   ```bash
   spark-submit notebooks_local/2_local_update_stocks.py --days 7
   ```
7. **Analytics & validation**
   ```bash
   spark-submit notebooks_local/3_local_analysis.py
   ```
   - Generates console reports, optional CSV exports, and runs stock consistency checks.

---

## Synthetic Data Details

- **Products**: 1,000–5,000 electronics SKUs across TVs, phones, laptops, audio, appliances, gaming, networking, accessories.
- **Suppliers**: 20–50 suppliers with ratings, lead times, capacities, contract windows, and category focus.
- **Inventory**: 7 days × 3 warehouses (`FRA`, `BUC`, `MAD`), CSV per day/warehouse. Fields include thresholds, lead time, last sale/update timestamps, and cumulative revenue.
- **Sales stream**: 10 JSON Lines files × 500 events (last 24 h). Includes rare invalid product IDs to exercise dead-letter logging.
- **Schemas**: Auto Loader compatible definitions stored under `resources/schemas/`.

Regenerate anytime with `src/generate_synthetic_data.py` (tunable via CLI flags).

---

## Delta Live Tables Highlights

- Bronze ingestion via `cloud_files` (CSV + JSON) and Kafka streaming.
- Silver cleansing with DLT expectations (`ON VIOLATION DROP/FAIL`), watermarking, and deduplication by `ROW_NUMBER`.
- Product enrichment, invalid product quarantine, supplier normalization.
- Gold layer: global inventory levels, hourly sales performance, IQR anomaly detection.
- Photon + autoscaling configuration baked into `bundle/databricks.yml`.

---

## Validation & Acceptance Criteria

- **Local run**: Steps 2–7 above complete successfully; validations in `3_local_analysis.py` report no failures.
- **Databricks run**: DLT pipeline reaches `gold_*` tables populated, dashboard queries return data within ~3 minutes on sample data.
- **Data quality**: Expectations remain green; `silver_sales_invalid_products` captures mismatches.
- **Performance**: AQE enabled, Delta OPTIMIZE/Z-Order guidance in docs, local jobs finish < 2 minutes on sample.
- **Artifact bundle**: `global_electronics_lakehouse.zip` (generated via `python -m zipfile` instructions below) ready for GitHub.

Validation script steps:

```bash
spark-submit notebooks_local/3_local_analysis.py --reports-dir _reports
```

- Verifies 100 random product/warehouse pairs: `old_stock - sold_today == new_stock`.
- Asserts no negative inventory quantities.

---

## Performance Checklist

- Enable AQE + dynamic partition pruning (already set in scripts).
- Broadcast small dimensions (`silver_product_reference`).
- Run `OPTIMIZE ... ZORDER BY (product_id)` on Delta tables after bulk loads.
- Vacuum with safe retention (`VACUUM ... RETAIN 168 HOURS`) to preserve Time Travel.
- Consider Delta Cache or Photon for heavy downstream analytics.

---

## Troubleshooting

- **Kafka offsets**: Reset consumer group via `kafka-consumer-groups.sh --reset-offsets ...` if DLT stops consuming.
- **Schema drift**: Update schema hints in `electronics_dlt.sql` or adjust Auto Loader evolution mode.
- **Delta conflict**: If concurrent writers collide locally, rerun merge (Delta handles optimistic concurrency).
- **Unity Catalog permissions**: Grant `READ`, `SELECT`, `USAGE` on catalog/schema/volumes to pipeline service principal.

---

## Packaging & GitHub

1. Generate ZIP (run from project root):
   ```bash
   python -m zipfile -c global_electronics_lakehouse.zip global_electronics_lakehouse
   ```
2. Initialize repository:
   ```bash
   git init
   git add .
   git commit -m "feat: initial global lakehouse project"
   git remote add origin <your_repo_url>
   git push -u origin main
   ```

---

## License

Released under the MIT License. See [`LICENSE`](LICENSE).
