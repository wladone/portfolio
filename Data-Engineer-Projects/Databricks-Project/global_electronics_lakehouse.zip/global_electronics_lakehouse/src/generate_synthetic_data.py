﻿"""Synthetic data generator for the Global Electronics Lakehouse project."""
from __future__ import annotations

import argparse
import csv
import json
import random
import string
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path


WAREHOUSES = ["FRA", "BUC", "MAD"]
CATEGORIES = {
    "Televisions": 0.12,
    "Smartphones": 0.18,
    "Laptops": 0.16,
    "Audio": 0.10,
    "Appliances": 0.14,
    "Accessories": 0.12,
    "Gaming": 0.08,
    "Networking": 0.10,
}
CHANNELS = ["online", "retail", "call_center", "mobile_app"]
PAYMENTS = ["card", "paypal", "bank_transfer", "cash"]
DEVICES = ["desktop", "mobile", "tablet"]
PROMO_CODES = ["SPRING10", "FREESHIP", "LOYALTY", "FLASH"]
COUNTRIES = ["Germany", "France", "Romania", "Spain", "Italy", "Netherlands"]


@dataclass
class Product:
    product_id: str
    product_name: str
    category: str
    base_price: float
    unit_cost: float
    supplier_id: str
    restock_threshold: int
    restock_lead_days: int


def random_string(prefix: str, length: int = 6) -> str:
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=length))
    return f"{prefix}{suffix}"


def build_suppliers(count: int) -> list[dict]:
    suppliers: list[dict] = []
    for idx in range(1, count + 1):
        supplier_id = f"SUP{idx:03d}"
        categories = random.sample(list(CATEGORIES.keys()), k=random.randint(2, 4))
        start_date = datetime.utcnow() - timedelta(days=random.randint(180, 720))
        end_date = start_date + timedelta(days=random.randint(365, 1095))
        suppliers.append(
            {
                "supplier_id": supplier_id,
                "supplier_name": f"{random.choice(['Nova', 'Prime', 'Vertex', 'Axiom', 'Helios', 'Aurora'])} Electronics {idx}",
                "rating": round(random.uniform(3.2, 4.9), 2),
                "lead_time_days": random.randint(5, 20),
                "preferred": random.random() < 0.55,
                "contact_email": f"contact+{supplier_id.lower()}@globalelectro.example", 
                "phone": f"+33{random.randint(100000000, 999999999)}",
                "country": random.choice(COUNTRIES),
                "category_focus": categories,
                "contract_start": start_date.strftime("%Y-%m-%d"),
                "contract_end": end_date.strftime("%Y-%m-%d"),
                "annual_capacity_units": random.randint(10000, 50000),
            }
        )
    return suppliers


def build_products(count: int, suppliers: list[dict]) -> list[Product]:
    weights = list(CATEGORIES.values())
    categories = list(CATEGORIES.keys())
    products: list[Product] = []
    for idx in range(1, count + 1):
        category = random.choices(categories, weights=weights, k=1)[0]
        base_price = round(random.uniform(30.0, 2500.0), 2)
        unit_cost = round(base_price * random.uniform(0.55, 0.82), 2)
        supplier = random.choice(suppliers)
        restock_threshold = random.randint(10, 60)
        restock_lead_days = random.randint(3, 14)
        products.append(
            Product(
                product_id=f"PRD{idx:05d}",
                product_name=f"{category.replace(' ', '')}-{idx:05d}",
                category=category,
                base_price=base_price,
                unit_cost=unit_cost,
                supplier_id=supplier["supplier_id"],
                restock_threshold=restock_threshold,
                restock_lead_days=restock_lead_days,
            )
        )
    return products


def write_suppliers(suppliers: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for record in suppliers:
            handle.write(json.dumps(record))
            handle.write("\n")
    print(f"Suppliers written: {len(suppliers)} -> {path}")


def write_inventory(products: list[Product], days: int, base_dir: Path) -> None:
    today = datetime.utcnow().date()
    total_rows = 0
    for offset in range(days):
        current_date = today - timedelta(days=offset)
        day_dir = base_dir / current_date.strftime("%Y-%m-%d")
        day_dir.mkdir(parents=True, exist_ok=True)
        for warehouse in WAREHOUSES:
            file_path = day_dir / f"{warehouse}_inventory.csv"
            with file_path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(
                    [
                        "inventory_date",
                        "warehouse_code",
                        "product_id",
                        "product_name",
                        "category",
                        "quantity_on_hand",
                        "unit_cost_euro",
                        "supplier_id",
                        "restock_threshold",
                        "restock_lead_days",
                        "is_active",
                        "last_updated_ts",
                        "last_sale_ts",
                        "lifetime_revenue_euro",
                    ]
                )
                for product in products:
                    quantity = max(0, int(random.gauss(120, 35)))
                    last_updated = datetime.combine(current_date, datetime.min.time()) + timedelta(hours=random.randint(0, 22), minutes=random.randint(0, 59))
                    last_sale = last_updated - timedelta(hours=random.randint(1, 48))
                    lifetime_revenue = round(quantity * product.base_price * random.uniform(15, 65), 2)
                    writer.writerow(
                        [
                            current_date.isoformat(),
                            warehouse,
                            product.product_id,
                            product.product_name,
                            product.category,
                            quantity,
                            product.unit_cost,
                            product.supplier_id,
                            product.restock_threshold,
                            product.restock_lead_days,
                            True,
                            last_updated.isoformat(),
                            last_sale.isoformat(),
                            lifetime_revenue,
                        ]
                    )
                    total_rows += 1
    print(f"Inventory rows written: {total_rows}")


def build_sales_events(
    products: list[Product],
    sales_files: int,
    events_per_file: int,
    invalid_ratio: float,
) -> list[list[dict]]:
    batches: list[list[dict]] = []
    all_events: list[dict] = []
    now = datetime.utcnow()
    for _ in range(sales_files * events_per_file):
        event_time = now - timedelta(minutes=random.randint(0, 60 * 24))
        if random.random() < invalid_ratio:
            product = random.choice(products)
            product_id = product.product_id + "_INVALID"
        else:
            product = random.choice(products)
            product_id = product.product_id
        order_id = random_string("ORD", 8)
        quantity = max(1, int(random.gauss(3, 1.2)))
        discount = round(random.choice([0.0, 0.05, 0.10, 0.15]) if random.random() < 0.35 else 0.0, 2)
        channel = random.choice(CHANNELS)
        payment = random.choice(PAYMENTS)
        warehouse = random.choice(WAREHOUSES)
        event = {
            "event_id": random_string("EVT", 10),
            "event_time": event_time.strftime("%Y-%m-%dT%H:%M:%S"),
            "order_id": order_id,
            "product_id": product_id,
            "warehouse_code": warehouse,
            "channel": channel,
            "payment_type": payment,
            "customer_id": random_string("CUST", 6),
            "quantity": quantity,
            "unit_price_euro": round(product.base_price * random.uniform(0.9, 1.1), 2),
            "discount_rate": discount,
            "currency": "EUR",
            "sales_channel_region": random.choice(["EU-West", "EU-Central", "EU-South"]),
            "promotion_code": random.choice(PROMO_CODES) if discount > 0 else None,
            "is_priority_order": random.random() < 0.08,
            "device_type": random.choice(DEVICES),
        }
        all_events.append(event)
    for idx in range(sales_files):
        start = idx * events_per_file
        end = start + events_per_file
        batches.append(all_events[start:end])
    return batches


def write_sales(batches: list[list[dict]], base_dir: Path) -> None:
    base_dir.mkdir(parents=True, exist_ok=True)
    for idx, events in enumerate(batches, start=1):
        file_path = base_dir / f"sales_{idx:03d}.json"
        with file_path.open("w", encoding="utf-8") as handle:
            for event in events:
                handle.write(json.dumps(event))
                handle.write("\n")
    print(f"Sales files written: {len(batches)} -> {base_dir}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate synthetic data for the Global Electronics Lakehouse project.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--products", type=int, default=2500, help="Number of products to generate")
    parser.add_argument("--days", type=int, default=7, help="Number of days of inventory history")
    parser.add_argument("--suppliers", type=int, default=30, help="Number of suppliers")
    parser.add_argument("--sales-files", type=int, default=10, help="Number of sales JSON files")
    parser.add_argument("--events-per-file", type=int, default=500, help="Events per sales file")
    parser.add_argument("--invalid-ratio", type=float, default=0.01, help="Fraction of sales with invalid product_id")
    parser.add_argument("--output", default=str(Path(__file__).resolve().parents[1] / "data"), help="Output data directory")
    args = parser.parse_args()

    random.seed(args.seed)

    output_dir = Path(args.output)
    inventory_dir = output_dir / "inventory"
    suppliers_dir = output_dir / "suppliers"
    sales_dir = output_dir / "sales_stream"

    suppliers_dir.mkdir(parents=True, exist_ok=True)

    suppliers = build_suppliers(max(20, min(args.suppliers, 50)))
    products = build_products(max(1000, min(args.products, 5000)), suppliers)

    write_suppliers(suppliers, suppliers_dir / "suppliers_master.jsonl")
    write_inventory(products, args.days, inventory_dir)
    sales_batches = build_sales_events(products, args.sales_files, args.events_per_file, args.invalid_ratio)
    write_sales(sales_batches, sales_dir)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
